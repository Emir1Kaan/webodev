<?php 
$baglanti=mysqli_connect('localhost','root','','kuafor');
if(!$baglanti) {
echo "Veri tabanına bağlanılamadı ".mysqli_connect_error();

}

mysqli_set_charset($baglanti,"uft");
?>